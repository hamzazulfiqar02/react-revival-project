import BestDeals from "./best-deals";
import DiningCategories from "./dining-categories";
import HeroSection from "./hero-section";
import HomeMobile from "./home-mobile";
import Recomendations from "./recomendations";

export { BestDeals, DiningCategories, HeroSection, HomeMobile, Recomendations };
